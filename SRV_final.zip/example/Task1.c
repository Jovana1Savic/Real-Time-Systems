/*
 * @file Task1.c
 * @brief
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */

/* Standard includes. */
#include <Task1.h>
#include <adc.h>
#include <Task2.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Hardware includes. */
#include "msp430.h"

TaskHandle_t xTask1;     //!< Task1 handle.

QueueHandle_t xTask1QueueT3; //!< Task3 mailbox.

QueueHandle_t xTask1QueueT4; //!< Task4 mailbox.

QueueSetHandle_t xQueueSet; //!< QueueSet handle.

/*
 * @brief Task1 - processes ADC results and sends them to Task3 or Task4.
 *
 * @detail A message is sent from Task2 which contains task id (Task3 or Task4).
 * Last 4 results of conversion for each channel are taken and average is calculated.
 * These average values are combined into one 32bit number which is sent to Task3 or
 * Task4 (based on id received from Task2) via mailbox.
 */
extern void prvTask1( void *pvParameters )
{
    /* "Buffers" used to keep last 4 values.
     * Last 4 8-bit values are packed into one 32bit number. */
    uint32_t uiChannel[4] = { 0 };

    /* Buffers used for queue messages. */
    ADCMsg_t xADCData;
    Task2Msg_t xTaskID;

    QueueSetMemberHandle_t xActivatedMember;

    xQueueSet = xQueueCreateSet( COMBINED_LENGTH );
    xQueueAddToSet( xADCDataQueue, xQueueSet );
    xQueueAddToSet( xTask2Queue, xQueueSet );
    for ( ; ; )
    {
        /* Wait for ADC message and xTask2 message. */
        xActivatedMember = xQueueSelectFromSet( xQueueSet, portMAX_DELAY );

        /* Process ADC message - save last 4 values. */
        if ( xActivatedMember == xADCDataQueue )
        {
            xQueueReceive( xADCDataQueue, &( xADCData ), 0 );

            uiChannel[xADCData.eADCchannel] = uiChannel[xADCData.eADCchannel] << 8; //!< Shift oldest 8bits to make room.
            uiChannel[xADCData.eADCchannel] += xADCData.usADCData;
        }
        if ( xActivatedMember == xTask2Queue )
        {
            xQueueReceive( xTask2Queue, &( xTaskID ), 0 );

            /* Find average for each channel. */
            uint8_t i = 0;
            uint32_t ucAverage[4] = { 0 };
            for ( ; i < 4 ; i++ )
            {
                ucAverage[i] = ( uint8_t )( uiChannel[i] ) + ( uint8_t )( uiChannel[i] >> 8 );
                ucAverage[i] += ( uint8_t )( uiChannel[i] >> 16 ) + ( uint8_t )( uiChannel[i] >> 24 );
                ucAverage[i] = ucAverage[i] >> 2;
            }

            /* Put averages into one 32bit number and send it to xTask3 or xTask4. */
            Task1Msg_t xMsg;
            xMsg.uiValue = ( ucAverage[0] ) + ( ucAverage[1] << 8 );
            xMsg.uiValue += ( ucAverage[2]  << 16 ) + ( ucAverage[3]  << 24 );

            if ( xTaskID.eTaskID == task3)
            {
                xQueueOverwrite( xTask1QueueT3, &( xMsg ) );
            }
            else
            {
                xQueueOverwrite( xTask1QueueT4, &( xMsg ) );
            }
        }
    }
}

/*
 * @brief Task1 initialization - creates mailboxes and task.
 *
 * @detail Creates task and two mailboxes - one for Task3 and one for Task4.
 */
void vInitTask1( void )
{
    xTaskCreate( prvTask1, "Task1", configMINIMAL_STACK_SIZE, NULL, TASK1_PRIO, &xTask1 );
    xTask1QueueT3 = xQueueCreate( task1MSG_QUEUE_LEN, sizeof( Task1Msg_t ) );
    xTask1QueueT4 = xQueueCreate( task1MSG_QUEUE_LEN, sizeof( Task1Msg_t ) );

}
