/*
 * @file LEDdisplay.h
 * @brief Contains everthing related to LED display - timer used for multiplexing,
 * mutex to protect, number that's beeing currently displayed as well as the current
 * digit (weight).
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */


#ifndef _LED_DISPLAY_H_
#define _LED_DISPLAY_H_

#include "FreeRTOS.h"
#include "semphr.h"
#include "timers.h"
#include "hal_LEDdisplay.h"

/*
 * ***************************************************************************
 *          Type declarations and defines. Variable declarations.
 * ***************************************************************************
 */

/** timer period */
#define TIMER5_PERIOD     ( pdMS_TO_TICKS( 5 ) )

extern uint16_t uiDisplayNumber;        //!< Number displayed on LED display.

extern uint8_t ucDisplayWeight;         //!< Current digit.

extern SemaphoreHandle_t xLEDMutex;     //!< Mutex used to protect LED display.

extern TimerHandle_t xTimer5;          //!< Timer handle.

/*
 * ***************************************************************************
 *                         Function declarations.
 * ***************************************************************************
 */

/*
 * @brief Timer callback function.
 *
 * @detail Displays one digit and prepares for next one.
 */
extern void vTimer5Callback( TimerHandle_t xTimer );

/*
 * @brief Initialize LED display.
 *
 * @detail Initialize hardware, timer and variables.
 */
extern void vInitDisplay( void );

#endif /* _LED_DISPLAY_H_ */
