/*
 * @file Task2.h
 * @brief Contains everything related to xTask2. This task checks if S3 or S4
 * buttons are pressed and notifies xTask1 by sending message.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */

/* Standard includes. */
#include <Task2.h>
#include <stdlib.h>

/* Hardware includes. */
#include "msp430.h"

TaskHandle_t xTask2;     //!< Task2 handle.

QueueHandle_t xTask2Queue; //!< Task2 message queue handle.

TimerHandle_t xTimer50;        //!< Timer handle (used for debauncing).

/*
 * @brief Task2 - polls S3 and S4.
 *
 * @detail When button is pressed a corresponding message is put into message queue
 * (mailbox).
 */
void prvTask2( void *pvParameters )
{
    uint8_t ucLastStateS3 = 0, ucStateS3 = 0;
    uint8_t ucLastStateS4 = 0, ucStateS4 = 0;
    xTimerStart( xTimer50, 0 );
    for( ;; )
    {
        ulTaskNotifyTake( pdTRUE, portMAX_DELAY );
        /* Read S3. */
        ucStateS3 = P2IN & BIT6;
        if( ( ucStateS3 == 0x00 ) && ( ucLastStateS3 == BIT6 ) )
        {
            Task2Msg_t xMsg = { task3 };
            xQueueOverwrite( xTask2Queue, &xMsg );
        }
        ucLastStateS3 = ucStateS3;

        /* Read S4. */
        ucStateS4 = P2IN & BIT7;
        if( ( ucStateS4 == 0x00 ) && ( ucLastStateS4 == BIT7 ) )
        {
            Task2Msg_t xMsg = { task4 };
            xQueueOverwrite( xTask2Queue, &xMsg );
        }
        ucLastStateS4 = ucStateS4;
    }
}

/*
 * @brief Timer callback function.
 *
 * @detail Starts conversion by notifying ADC task.
 */
void vTimer50Callback( TimerHandle_t xTimer )
{
    xTaskNotifyGive( xTask2 );
}

/*
 * @brief Task2 initialization.
 *
 * @detail Creates Task2 and its message queue (mailbox).
 */
void vInitTask2( void )
{
    xTaskCreate( prvTask2, "Task 2", configMINIMAL_STACK_SIZE, NULL, TASK2_PRIO, &xTask2 );
    xTask2Queue = xQueueCreate( task2MSG_QUEUE_LEN, sizeof( Task2Msg_t ) );
    xTimer50 = xTimerCreate( "Timer50", TIMER50_PERIOD, pdTRUE, NULL, vTimer50Callback);

}


