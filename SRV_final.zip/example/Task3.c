/*
 * @file Task3.c
 * @brief Contains everything related to xTask2. This task checks if S3 or S4
 * buttons are pressed and notifies xTask1 by sending message.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */

/* Standard includes. */
#include <Task3.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Hardware includes. */
#include "msp430.h"

TaskHandle_t xTask3;

TimerHandle_t xTimerT3;

/*
 * @brief Task3 - writes to LED display.
 *
 * @detail When given mutex writes on LED display.
 */
void prvTask3( void *pvParameters )
{
    uint32_t ulMessage = 0;
    uint16_t uiDisplay = 0;
    xTimerStart( xTimerT3, 0 );
    for ( ; ; )
    {
        ulTaskNotifyTake( pdTRUE, portMAX_DELAY );

        /* Receive message from xTask1, but don't block if there's nothing. */
        if ( xQueueReceive( xTask1QueueT3, &( ulMessage ), ( TickType_t ) 0 ) == pdTRUE)
        {
            /* Display only 4 upper bits of each byte in ulMessage.*/
            uint8_t b0 = ( uint8_t ) ( ulMessage & 0xf0 );
            uint8_t b1 = ( uint8_t ) (( ulMessage & 0xf000 ) >> 8);
            uint8_t b2 = ( uint16_t ) (( ulMessage & 0xf00000  ) >> 16) ;
            uint8_t b3 = ( uint16_t ) (( ulMessage & 0xf0000000 ) >> 24);

            uiDisplay = (b0 >> 4) + b1 + (b2 << 4) + (b3 << 8);

            /* Since message was received try to take mutex. */
            if( xSemaphoreTake( xLEDMutex, portMAX_DELAY ) == pdTRUE )
            {
                uiDisplayNumber = uiDisplay;
            }
            else
            {
                /* we should never get here, halt */
                for( ;; );
            }
            /* release mutex */
            xSemaphoreGive( xLEDMutex );
        }
    }
}

/*
 * @brief Timer callback function.
 *
 * @detail Unblocks task3.
 */
void vTimerT3Callback( TimerHandle_t xTimer )
{
    xTaskNotifyGive( xTask3 );
}

void vInitTask3( void )
{
    xTaskCreate( prvTask3, "Task3", configMINIMAL_STACK_SIZE, NULL, TASK3_PRIO, &xTask3 );
    xTimerT3 = xTimerCreate( "TimerT3", TASK3_SYNC_DELAY, pdTRUE, NULL, vTimerT3Callback);

}
