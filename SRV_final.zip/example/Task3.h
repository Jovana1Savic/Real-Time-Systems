/*
 * @file Task3.h
 * @brief Contains everything related to xTask3. This task writes
 * values received from Task1 to LED display.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */


#ifndef _TASK3_H_
#define _TASK3_H_

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "timers.h"

/*
 * ***************************************************************************
 *          Type declarations and defines. Variable declarations.
 * ***************************************************************************
 */

#define TASK3_PRIO            ( 3 )     //!< Task1 priority.

/** delay used for task synchronization */
#define TASK3_SYNC_DELAY     ( pdMS_TO_TICKS( 20 ) )     /* ( ( ( TickType_t ) 20 ) / portTICK_PERIOD_MS ) */

extern QueueHandle_t xTask1QueueT3; //!< Task3's mailbox.

extern uint16_t uiDisplayNumber;    //!< Number displayed on LED display.

extern SemaphoreHandle_t xLEDMutex; //!< Mutex used to protect LED display.

extern TaskHandle_t xTask3;

/*
 * ***************************************************************************
 *                         Function declarations.
 * ***************************************************************************
 */

/*
 * @brief Task3 - writes to LED display.
 *
 * @detail When given mutex writes on LED display.
 */
extern void prvTask3( void *pvParameters );

/*
 * @brief Initialize task2.
 *
 * @detail Create task and message queue.
 */
extern void vInitTask3( void );

/*
 * @brief Timer callback function.
 *
 * @detail Unblocks Task3 every 50ms .
 */
extern void vTimerT3Callback( TimerHandle_t xTimer );

#endif /* _TASK3_H_ */
