/*
 * @file Task3.h
 * @brief Contains everything related to xTask3. This task writes
 * values received from Task1 to LED display.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */


#ifndef _TASK4_H_
#define _TASK4_H_

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "timers.h"

/*
 * ***************************************************************************
 *          Type declarations and defines. Variable declarations.
 * ***************************************************************************
 */

#define TASK4_PRIO            ( 3 )     //!< Task4 priority.

/** delay used for task synchronization */
#define TASK4_SYNC_DELAY     ( pdMS_TO_TICKS( 20 ) )     /* ( ( ( TickType_t ) 20 ) / portTICK_PERIOD_MS ) */

extern QueueHandle_t xTask1QueueT4; //!< Task3's mailbox.

extern uint16_t uiDisplayNumber;    //!< Number displayed on LED display.

extern SemaphoreHandle_t xLEDMutex; //!< Mutex used to protect LED display.

extern TaskHandle_t xTask4;

/*
 * ***************************************************************************
 *                         Function declarations.
 * ***************************************************************************
 */

/*
 * @brief Task3 - writes to LED display.
 *
 * @detail When given mutex writes on LED display.
 */
extern void prvTask4( void *pvParameters );

/*
 * @brief Initialize task2.
 *
 * @detail Create task and message queue.
 */
extern void vInitTask4( void );

#endif /* _TASK4_H_ */
