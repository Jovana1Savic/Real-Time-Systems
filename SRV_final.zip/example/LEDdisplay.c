/*
 * @file LEDdisplay.c
 * @brief Contains everything related to LEDdisplay. This task writes
 * values received from Task1 to LED display.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */

#include "LEDdisplay.h"

uint16_t uiDisplayNumber;    //!< Number displayed on LED display.

uint8_t ucDisplayWeight;    //!< Current digit.

SemaphoreHandle_t xLEDMutex; //!< Mutex used to protect LED display.

TimerHandle_t xTimer5;        //!< Timer handle.

/*
 * @brief Timer callback function.
 *
 * @detail Display number's digit at ucDisplayWeight and increment
 * weight.
 */
void vTimer5Callback( TimerHandle_t xTimer )
{
    vDisplayNibble( uiDisplayNumber, ucDisplayWeight );
    ucDisplayWeight++;
    ucDisplayWeight &= 0x03;
}

/*
 * @brief Initialize LED display.
 *
 * @detail Initialize hardware, timer and variables.
 */
void vInitDisplay( void )
{
    /* Initialize variables and mutex. */
    ucDisplayWeight = 0;
    uiDisplayNumber = 0;
    xLEDMutex = xSemaphoreCreateMutex();

    /* Initialize hardware. */
    vHALInitLEDdisplay();

    /* Start timer. */
    xTimer5 = xTimerCreate( "Timer5", TIMER5_PERIOD, pdTRUE, NULL, vTimer5Callback );
    xTimerStart( xTimer5, 0 );
}
