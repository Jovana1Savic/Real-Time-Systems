/*
 * @file Task1.h
 * @brief Contains everything related to xTask1. Once it gets ADC
 * results from ADC interrupt routine and task id from Task2 sends average of
 * last 4 values from each channel to Task3 or Task4.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */

#ifndef _TASK1_H_
#define _TASK1_H_

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/*
 * ***************************************************************************
 *                      Type declarations and defines.
 * ***************************************************************************
 */

#define TASK1_PRIO            ( 1 )     //!< Task1 priority.

#define task1MSG_QUEUE_LEN    ( 1 )      //!< Message queue length.

#define COMBINED_LENGTH ( adcADC_DATA_QUEUE_LEN + task2MSG_QUEUE_LEN)   //! QueueSet length.

/* Message that Task1 sends to xTask3 or xTask4. */
typedef struct
{
    uint32_t uiValue;  //!< Value sent via mailbox.
} Task1Msg_t;

/*
 * ***************************************************************************
 *                          Variable declarations.
 * ***************************************************************************
 */

extern TaskHandle_t xTask1;         //!< Task1 handle.

extern QueueHandle_t xTask1QueueT3; //!< Task3 mailbox.

extern QueueHandle_t xTask1QueueT4; //!< Task4 mailbox.

extern QueueSetHandle_t xQueueSet;  //!< QueueSet handle.
/*
 * ***************************************************************************
 *                         Function declarations.
 * ***************************************************************************
 */

/*
 * @brief Task1 - processes ADC results and sends them to Task3 or Task4.
 *
 * @detail A message is sent from Task2 which contains task id (Task3 or Task4).
 * Last 4 results of conversion for each channel are taken and average is calculated.
 * These average values are combined into one 32bit number which is sent to Task3 or
 * Task4 (based on id received from Task2) via mailbox.
 */
extern void prvTask1( void *pvParameters );

/*
 * @brief Initialize Task1.
 *
 * @detail Create task and two mailboxes.
 */
extern void vInitTask1( void );

#endif /* _TASK1_H_ */
