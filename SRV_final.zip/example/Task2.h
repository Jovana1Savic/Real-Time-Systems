/*
 * @file Task2.h
 * @brief Contains everything related to xTask2. This task checks if S3 or S4
 * buttons are pressed and notifies xTask1 by sending message.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date July 2018
 */

#ifndef _TASK2_H_
#define _TASK2_H_

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/*
 * ***************************************************************************
 *                      Type declarations and defines.
 * ***************************************************************************
 */

#define TASK2_PRIO            ( 2 )     //!< Task2 priority.

#define task2MSG_QUEUE_LEN    ( 1 )      //!< Message queue length.

/** timer period */
#define TIMER50_PERIOD     ( pdMS_TO_TICKS( 50 ) )

/* Defines tasks that can be sent as a message. */
typedef enum
{
    task3,    //!< Task 3
    task4     //!< Task 4
} taskID_t;

/* Message that Task2 sends. */
typedef struct
{
    taskID_t eTaskID;  //!< Task id.
} Task2Msg_t;

/*
 * ***************************************************************************
 *                          Variable declarations.
 * ***************************************************************************
 */

extern TaskHandle_t xTask2;     //!< Task2 handle.

extern QueueHandle_t xTask2Queue; //!< Task2 message queue handle.

/*
 * ***************************************************************************
 *                         Function declarations.
 * ***************************************************************************
 */

/*
 * @brief Task2 - used to poll S3 and S4.
 *
 * @detail If a button is pressed a message is sent to Task1.
 */
extern void prvTask2( void *pvParameters );

/*
 * @brief Initialize task2.
 *
 * @detail Create task and message queue.
 */
extern void vInitTask2( void );

/*
 * @brief Timer callback function.
 *
 * @detail Unblocks Task2 every 50ms .
 */
extern void vTimer50Callback( TimerHandle_t xTimer );

#endif /* _TASK2_H_ */
