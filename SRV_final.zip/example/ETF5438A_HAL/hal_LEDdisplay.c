/**
 * @file hal_LEDdisplay.c
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date 2018
 * @brief LED display API implementation
 *
 * @detail Segment table, initialization and display digit functions are defined.
 */

#include "hal_LEDdisplay.h"

/**
 * Table of settings for a-g lines for appropriate digit.
 */
const uint8_t LEDdisplayCode[]= {
                                 0x7E,
                                 0x30,
                                 0x6D,
                                 0x79,
                                 0x33,
                                 0x5b,
                                 0x5f,
                                 0x70,
                                 0x7f,
                                 0x7b,
                                 0x77,
                                 0x1f,
                                 0x4e,
                                 0x3d,
                                 0x4f,
                                 0x47
                         };

/**
 * @brief Initialize LED display.
 *
 * @detail Set ports directions and outputs.
 */
void vHALInitLEDdisplay( void )
{
    /* Set ports' directions. */
    P11DIR |= BIT1 | BIT0;
    P10DIR |= BIT6 | BIT7;
    P6DIR |= 0xff;

    /* Set to inactive value. */
    P11OUT |= BIT1 | BIT0;
    P10OUT |= BIT6 | BIT7;
    P6OUT = 0;
}

/**
 * @brief Display nibble from 16bit number as a digit.
 *
 * @detail Four bits from 16bit number are taken based on ucWeight. They
 * are displayed as a digit on corresponding segment.
 */
void vDisplayNibble( uint16_t ucNumber, uint8_t ucWeight )
{
    /* Make sure weight is in the right range. */
    ucWeight = ucWeight & 0x03;

    /* Take right 4 bits. */
    uint8_t ucDigit = (ucNumber >> (ucWeight << 2)) & 0x0f;

    /* Make sure SEL signals are set to inactive value. */
    P11OUT |= BIT1 | BIT0;
    P10OUT |= BIT6 | BIT7;

    /* Select right SEL signal based on digit weight. */
    switch ( ucWeight )
    {
        case 0: SEL1OUT &= ~SEL1; break;
        case 1: SEL2OUT &= ~SEL2; break;
        case 2: SEL3OUT &= ~SEL3; break;
        case 3: SEL4OUT &= ~SEL4; break;
    }

    P6OUT = LEDdisplayCode[ucDigit];
}

/**
 * @brief Display digit from 16bit number. Decimal display.
 *
 * @detail Four bits from 16bit number are taken based on ucWeight. They
 * are displayed as a digit on corresponding segment.
 */
void vDisplayDigit( uint16_t ucNumber, uint8_t ucWeight)
{
    /* Make sure weight is in the right range. */
    ucWeight = ucWeight & 0x03;

    /* Take right digit. */
    uint8_t ucDigit = ( ucNumber/( 10*ucWeight ) ) % 10;

    /* Make sure SEL signals are set to inactive value. */
    P11OUT |= BIT1 | BIT0;
    P10OUT |= BIT6 | BIT7;

    /* Select right SEL signal based on digit weight. */
    switch ( ucWeight )
    {
        case 0: SEL1OUT &= ~SEL1; break;
        case 1: SEL2OUT &= ~SEL2; break;
        case 2: SEL3OUT &= ~SEL3; break;
        case 3: SEL4OUT &= ~SEL4; break;
    }

    P6OUT = LEDdisplayCode[ucDigit];
}
