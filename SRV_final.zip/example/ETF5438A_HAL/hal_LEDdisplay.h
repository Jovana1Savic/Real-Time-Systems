/**
 * @file hal_LEDdisplay.h
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date 2018
 * @brief LED display API
 *
 * @detail Helper functions for LED display management
 */

/* Standard includes. */
#include <stdio.h>
#include <stdint.h>
#include "msp430.h"

/* Define selection ports. SEL1 corresponds to lowest weight digit. */
#define SEL1DIR     ( P10DIR )
#define SEL2DIR     ( P10DIR )
#define SEL3DIR     ( P11DIR )
#define SEL4DIR     ( P11DIR )

#define SEL1OUT     ( P10OUT )
#define SEL2OUT     ( P10OUT )
#define SEL3OUT     ( P11OUT )
#define SEL4OUT     ( P11OUT )

#define SEL1        ( BIT6 )
#define SEL2        ( BIT7 )
#define SEL3        ( BIT0 )
#define SEL4        ( BIT1 )

/* Define output port. */
#define DIGIT_DIR   ( P6DIR )
#define DIGIT_OUT   ( P6OUT )
#define DIGIT       ( 0xff )


/**
 * @brief Initialize ports supported by HAL
 *
 * @detail Initialize LED display ports and pins.
 */
extern void vHALInitLEDdisplay( void );

/**
 * @brief Display nibble from 16bit number as a digit. That is display number
 * in hexadecimal format.
 *
 * @detail Four bits from 16bit number are taken based on ucWeight. They
 * are displayed as a digit on corresponding segment.
 */
extern void vDisplayNibble( uint16_t ucNumber, uint8_t ucWeight);

/**
 * @brief Display digit from 16bit number. Decimal display.
 *
 * @detail Four bits from 16bit number are taken based on ucWeight. They
 * are displayed as a digit on corresponding segment.
 */
extern void vDisplayDigit( uint16_t ucNumber, uint8_t ucWeight);

