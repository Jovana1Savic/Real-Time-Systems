/**
 * @file adc.c
 * @brief ADC functions implementations.
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date June 2016
 *
 */

/* Standard includes. */
#include <adc.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Hardware includes. */
#include "msp430.h"

QueueHandle_t xADCDataQueue;    //!< Message queue handle.

TimerHandle_t xTimer100;        //!< Timer handle.

/**
 * @brief ADC task initialization.
 *
 * @detail Creates ADC task and message queue. Starts timer.
 */
void vADCInitADC(void)
{
    vADCInitHardware();
	xADCDataQueue = xQueueCreate( adcADC_DATA_QUEUE_LEN, sizeof( ADCMsg_t ) );
	xTimer100 = xTimerCreate( "Timer100", TIMER100_PERIOD, pdTRUE, NULL, vTimer100Callback);
	xTimerStart( xTimer100, 0 );
}

/**
 * @brief ADC hardware initialization.
 *
 * @detail Selects pins used for ADC, configures ADC.
 */
void vADCInitHardware(void)
{
	/* Setup pins. */
	P7SEL |= BIT6 + BIT7;
	P5SEL |= BIT0 + BIT1;

	/* Setup ADC. */
	ADC12CTL0 = ADC12ON | ADC12MSC;		                    //!< Use MSC.
	ADC12CTL1 = ADC12SHS_0 | ADC12CONSEQ_1 | ADC12SHP;	    //!< Repeat sequence.
	ADC12MCTL0 = ADC12INCH_14;
	ADC12MCTL1 = ADC12INCH_15;
	ADC12MCTL2 = ADC12INCH_8;
	ADC12MCTL3 = ADC12INCH_9 | ADC12EOS;	                //!< MEM3 is sequence end.
	ADC12IE |= ADC12IE0 | ADC12IE1 | ADC12IE2 | ADC12IE3;	//!< Enable all channels interrupts.
	ADC12CTL0 |= ADC12ENC;		                            //!< Enable conversion.
}

/**
 * @brief ADC interrupt service routine.
 *
 * @detail Conversion result is put into ADC message queue.
 */
void __attribute__ ( ( interrupt( ADC12_VECTOR ) ) ) vADCISR( void )
{
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;

	switch( ADC12IV )
	{
	case  6:					/* Vector  6: ADC12IFG0 */
	{
		ADCMsg_t xMsg = { CH0, ( uint8_t )( ADC12MEM0 >> 4 ) };
		xQueueSendToBackFromISR( xADCDataQueue, &xMsg, &xHigherPriorityTaskWoken );
	}
	break;
	case  8:					/* Vector  8: ADC12IFG1 */
	{
		ADCMsg_t xMsg = { CH1, ( uint8_t )( ADC12MEM1 >> 4 ) };
		xQueueSendToBackFromISR( xADCDataQueue, &xMsg, &xHigherPriorityTaskWoken );
	}
	break;
	case 10:					/* Vector 10: ADC12IFG2 */
	{
		ADCMsg_t xMsg = { CH2, ( uint8_t )( ADC12MEM2 >> 4 ) };
		xQueueSendToBackFromISR( xADCDataQueue, &xMsg, &xHigherPriorityTaskWoken );
	}
	break;
	case 12:					/* Vector 12: ADC12IFG3 */
	{
		ADCMsg_t xMsg = { CH3, ( uint8_t )( ADC12MEM3 >> 4 ) };
		xQueueSendToBackFromISR( xADCDataQueue, &xMsg, &xHigherPriorityTaskWoken );
	}
	break;
	default: break;
	}
}

/*
 * @brief Timer callback function.
 *
 * @detail Starts conversion by notifying ADC task.
 */
void vTimer100Callback( TimerHandle_t xTimer )
{
    adcSTART_CONV;
}
