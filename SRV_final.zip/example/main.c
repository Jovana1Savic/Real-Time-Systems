/**
 * @file main.c
 * @brief OE4SRV
 * @author Jovana Savic
 * @date 2018
 *
 */

/* Standard includes. */
#include <adc.h>
#include <stdio.h>
#include <stdlib.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Hardware includes. */
#include "msp430.h"
#include "hal_ETF5438A.h"

#include "Task1.h"
#include "Task2.h"
#include "Task3.h"
#include "Task4.h"
#include "adc.h"
#include "LEDdisplay.h"

static void prvSetupHardware( void );

/**
 * @brief Glavna funkcija
 *
 * Funkcija koja inicijalizuje taskove i objekte RTOS i startuje Scheduler
 */
void main( void )
{
    /* Configure peripherals */
    prvSetupHardware();

    /* Create tasks */
    vADCInitADC();
    vInitTask2();
    vInitTask1();
    vInitTask3();
    vInitTask4();
    vInitDisplay();

    taskENABLE_INTERRUPTS();

    /* Start the scheduler. */
    vTaskStartScheduler();

    /* If all is well then this line will never be reached.  If it is reached
    then it is likely that there was insufficient (FreeRTOS) heap memory space
    to create the idle task.  This may have been trapped by the malloc() failed
    hook function, if one is configured. */	
    for( ;; );
}

/**
 * @brief Inicijalizacija hardvera
 *
 * Standardna inicijalizacija hardvera
 */
static void prvSetupHardware( void )
{
    taskDISABLE_INTERRUPTS();

    /* Disable the watchdog. */
    WDTCTL = WDTPW + WDTHOLD;

    /* Configure Clock. Since we aren't using XT1 on the board,
     * configure REFOCLK to source FLL adn ACLK.
     */
    SELECT_FLLREF(SELREF__REFOCLK);
    SELECT_ACLK(SELA__REFOCLK);
    hal430SetSystemClock( configCPU_CLOCK_HZ, configLFXT_CLOCK_HZ );

}
