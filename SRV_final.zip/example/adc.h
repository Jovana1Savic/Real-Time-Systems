/**
 * @file adc.h
 * @brief Contains AD converter related functions and tasks declarations.
 * @detail A timer is used to start conversion every 100ms. Last 16 results
 * of conversion are put into message queue.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date June 2016
 */

#ifndef ADC_H_
#define ADC_H_

#include "FreeRTOS.h"
#include "timers.h"
#include "queue.h"

/*
 * ***************************************************************************
 *                      Type declarations and defines.
 * ***************************************************************************
 */

/*
 * ADC channel type.
 */
typedef enum
{
    CH0,    //!< Channel 0
    CH1,    //!< Channel 1
    CH2,    //!< Channel 2
    CH3     //!< Channel 3
} Channel_t;

/**
 * ADC message structure - contains channel id from which data was received as well
 * as upper 8 bits of conversion.
 */
typedef struct
{
	Channel_t eADCchannel;	//!< Channel number.
	uint8_t usADCData;      //!< Upper 8 bits of converted value.
} ADCMsg_t;

#define adcADC_DATA_QUEUE_LEN   ( 16 )      //!< Message queue length.

/*
 * ADC start conversion macro.
 */
#define adcSTART_CONV           do { ADC12CTL0 |= ADC12SC; } while( 0 )

/** timer period */
#define TIMER100_PERIOD     ( pdMS_TO_TICKS( 100 ) )

/*
 * ***************************************************************************
 *                          Variable declarations.
 * ***************************************************************************
 */

extern QueueHandle_t xADCDataQueue; //!< Message queue handle.

extern TimerHandle_t xTimer100;  //!< 100ms timer handle.

/*
 * ***************************************************************************
 *                         Function declarations.
 * ***************************************************************************
 */

/**
 * @brief ADC task initialization.
 *
 * @detail Initializes timer and creates message queue.
 */
extern void vADCInitADC(void);

/**
 * @brief ADC hardware initialization.
 *
 * @detail Selects right pins used for ADC, configures ADC in Repeat
 * Sequence of Channels mode, uses first 4 memory locations of ADC to store
 * results of conversion.
 */
extern void vADCInitHardware(void);

/*
 * @brief Timer callback function.
 *
 * @detail Notifies ADC task to start conversion every 100ms.
 */
extern void vTimer100Callback( TimerHandle_t xTimer );

#endif /* ADC_H_ */
